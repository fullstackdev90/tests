<?php
ini_set("display_errors",1);
error_reporting(-1);
require_once 'config.php';
require_once 'function.php';

if(isset($_POST['test']) ){
    print_r($_POST);
    die;
}


$tests=get_tests();
var_dump($tests);

if(isset($_POST['test'])){
    $test=(int)$_POST['test'];
    unset($_POST['test']);
    $result=get_correct_answers($test);
    if(!is_array($result))exit('ошибка!');
    $test_all_data_result=get_test_data_result($test_all_data, $result, $_POST);
    echo $test_all_data_result
    die;
}
if(isset ($_GET['test'])){
    $test_id=(int)$_GET['test'];
    $test_data=get_test_data($test_id);
    if(is_array($test_data)    ){
        $count_question=count($test_data);
        $pagination=pagination($count_questions, $test_data)
    }
};

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ситема тестирования</title>
</head>
<body>
    <div class="wrap">
    <?php if($test):?>
    <h3>Варианты тестов</h3>
    <?= foreach($tests as $test): ?>
        <p><a href="?test=<?=$test['id']?>"><?=$test['test_name']?></a></p>
        <?= endforeach:?>
            <br><hr><br>
            <div class="content">
                <?= if(isset($test_data))?>
                    <?= if(is_array($test_data)): ?>
                    <p>количество вопросов:>?= $count_question?></p>
                   <?= $pagination?>
                   <span class="none" id="test-id"><?=$test_id?></span>
                    <div class="test-data">
                        <?= foreach($test_data as $id_question => $item)?>
                        <div class="question" data-id="<?= $id_question?>" id="question-<?= $id_question?>">
                        <?= foreach($item as $id_answer=> $answer)?>
                        <?= if(!$id_answer)?>
                        <p class="q"><?=$answer?>
                    <?= else:?>
                    <p class="a">
                    <input type="radio" id="answer-<?= $id_answer?> " name="<?= $id_question?>" value="<?=$id_answer?>">
                    <label for="answer-<?=$id_answer?>"><?= $answer</lebel>
                    </p>
                    <?= endif;?>
                        <?= endforeach?>
                        </div>
                        <?= endforeach?>
                    </div>
                    <div class="buttons">
                    <buttons class="center btn" id="btn">закончить тест</buttons>
                    <?= else : ?>
                        пройти тест
                    <?= endif;?>
                <?=else: ?>
                    Начать тест
                <?= endif; ?>
                Вопросы для тестирования теста
            </div>
            <?=else:?>
<h3>нет тестов</h3>
            <?= endif;?>
    </div>
    <script src="http://code.jquery.com/jquery-latest.js"></scripts>
    <scripts src="scripts.js">
</body>
</html>