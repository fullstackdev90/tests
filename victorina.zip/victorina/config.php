<?php
define("HOST", "localhost");
define("USER", "root");
define("PASS", "");
define("DB", "testing");

$db= @mysqli_connect(HOST, USER, PASS, DB) or die('нет соединения БД');
mysqli_set_charset($db, 'utf8')or die('не установлена кодировка соединения');